# BhashaBuddy – VoiceBridge (v2.0)

A multilingual technical-English learning application built with React and Vite. This is an improved version of the supplied project, retaining its 50-word dataset and original learning flow.

## Features
- English, Telugu, Hindi and Tamil interface languages
- 50 technical vocabulary entries with translations, phonetic guides and engineering examples
- Search and difficulty filters
- Browser text-to-speech
- Browser speech recognition with permission/error guidance
- Text-entry fallback when speech recognition is unavailable
- Five-question multiple-choice quiz
- Daily goal, completed words and learning streak
- Responsive layout and keyboard focus improvements
- Existing v1 learning progress is migrated into the new namespaced storage keys when available

## Windows setup
1. Install Node.js LTS from https://nodejs.org/.
2. Extract this ZIP.
3. Open the `BhashaBuddy` folder in VS Code.
4. Select **Terminal → New Terminal**.
5. Run `npm install`.
6. Run `npm run dev`.
7. Open the localhost URL shown in the terminal (usually `http://localhost:5173`).
8. Use Chrome or Edge and allow microphone access when prompted.

## Automated tests
Run:
- `npm test` – run the automated unit tests
- `npm run coverage` – generate a coverage report
- `npm run build` – create the production build in `dist`

The test suite covers text normalization, exact/partial/empty pronunciation matching, safe storage parsing and local date handling. Run these commands after installing dependencies and retain the terminal output as project evidence.

## Updated project structure
- `src/App.jsx` – main learning UI and app state
- `src/components/ErrorBoundary.jsx` – recoverable UI error boundary
- `src/hooks/useSpeech.js` – speech recognition lifecycle, cleanup and speech synthesis
- `src/lib/scoring.js` – pronunciation text similarity
- `src/lib/storage.js` – defensive, namespaced browser storage and legacy migration
- `src/lib/*.test.js` – automated tests
- `src/words.js` – original 50-word technical vocabulary
- `src/style.css` – responsive styles and accessibility focus states
- `public/_headers` – security headers for compatible static hosts
- `SECURITY.md` – security controls, limitations and production checklist

## Demo sequence
1. Open the app and choose Telugu.
2. Show the Algorithm flashcard and its meaning.
3. Press Listen to hear the English word.
4. Press Speak and allow microphone access.
5. Show the recognized text and match percentage.
6. Use the text fallback and show the score.
7. Complete a flashcard and show the progress tab.
8. Complete the daily quiz.
9. Run `npm test` and show the passing test output.

## Important technical limitations
- This is a frontend-only prototype. Learning progress is stored on the current browser/device; it is not synchronized to a cloud account.
- LocalStorage is not a secure database. Never store passwords, tokens or sensitive personal information there.
- Browser speech recognition support and audio-processing privacy depend on the browser vendor.
- The percentage is a text similarity score based on edit distance, not a scientific acoustic pronunciation score.
- Security headers in `public/_headers` are recognized by compatible hosting providers such as Netlify; configure equivalent headers for other hosts.
- A production multi-user release needs a server-side database, authentication, per-user authorization, HTTPS, rate limiting and server-side validation. See `SECURITY.md`.

## Assessment improvement evidence
The supplied rubric identified missing automated tests, weak microphone error guidance, a monolithic main component, local-only persistence, basic validation and limited security documentation. This revision addresses the frontend portions with tests, modular utilities/hooks, defensive storage, clearer speech errors, an error boundary, accessibility improvements and deployment security-header guidance. Backend/cloud features remain clearly identified as production work rather than being misrepresented as implemented.

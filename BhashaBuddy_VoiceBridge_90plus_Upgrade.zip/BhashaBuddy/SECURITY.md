# Security and privacy

## Improvements
- No API keys, passwords, or secrets are shipped in the browser bundle.
- Learner text is handled as text and rendered by React; no dynamic HTML injection is used.
- Local persistence is namespaced and JSON parsing/storage failures are handled safely.
- Microphone access starts only after the user presses Speak. Unsupported browsers, permission denial, missing microphone, network errors, and no-speech cases have guidance.
- Speech recognition listeners are cleaned up when the hook unmounts.
- A React error boundary provides a recovery screen.
- Static security headers are provided in `public/_headers` for compatible hosts such as Netlify.

## Honest limitations
- This remains a frontend prototype. LocalStorage is editable by someone with access to the browser profile and is not a secure database. Never store passwords, authentication tokens, or sensitive records there.
- Progress is device-local. Multi-device profiles require a server database, authenticated API, server-side authorization, HTTPS, rate limiting, audit logs, backups, and retention controls.
- Browser speech recognition may send audio to the browser vendor's speech service. This app does not itself record or upload audio.
- The pronunciation percentage compares recognized text with the target using edit distance; it is not an acoustic or phonetic assessment.
- `_headers` works only on hosts that support this convention. Configure equivalent headers at other hosts.

## Production checklist
1. HTTPS only.
2. Server-side authentication and per-user authorization for cloud profiles.
3. Server-side input validation; never trust client validation alone.
4. Rate limits on authentication and API endpoints.
5. Password hashing with Argon2id or bcrypt; never plaintext passwords.
6. Secrets in server environment variables, never `VITE_*` variables.
7. A restrictive Content Security Policy compatible with the selected host and speech features.
8. Dependency audit using `npm audit` and regular updates.
9. Component, accessibility, API authorization, and failure-state tests.

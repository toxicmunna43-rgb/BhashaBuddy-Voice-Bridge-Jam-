import React from 'react';
export default class ErrorBoundary extends React.Component {
 constructor(props){super(props);this.state={failed:false}}
 static getDerivedStateFromError(){return {failed:true}}
 componentDidCatch(error){console.error('BhashaBuddy UI error:',error)}
 render(){if(this.state.failed)return <main role="alert" className="content"><section className="quiz-box"><h2>Something went wrong</h2><p>Refresh the app to try again.</p><button className="primary" onClick={()=>window.location.reload()}>Refresh app</button></section></main>;return this.props.children}
}

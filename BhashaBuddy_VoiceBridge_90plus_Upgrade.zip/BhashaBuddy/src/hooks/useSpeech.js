import {useCallback,useEffect,useRef,useState} from 'react';
const ERRORS={'not-allowed':'Microphone permission was denied. Allow microphone access in browser settings.','service-not-allowed':'The browser blocked speech recognition. Check browser permissions.','audio-capture':'No microphone was detected. Connect or select a microphone.','no-speech':'No speech was detected. Try again.','network':'Speech recognition needs a network connection.','aborted':'Speech recognition was cancelled.'};
export function useSpeechRecognition({onTranscript,language='en-US'}={}) {
 const [status,setStatus]=useState('ready'),[error,setError]=useState(''),ref=useRef(null),callback=useRef(onTranscript);
 useEffect(()=>{callback.current=onTranscript},[onTranscript]);
 const stop=useCallback(()=>{try{ref.current?.stop()}catch{}},[]);
 const start=useCallback(()=>{
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){setStatus('unsupported');setError('Speech recognition is not supported. Use text practice below.');return}
  stop();setError('');
  try{const r=new SR();ref.current=r;r.lang=language;r.interimResults=false;r.maxAlternatives=1;
   r.onstart=()=>setStatus('listening');r.onresult=e=>{const value=e?.results?.[0]?.[0]?.transcript;if(typeof value==='string')callback.current?.(value);setStatus('done')};
   r.onerror=e=>{setError(ERRORS[e.error]||'Speech recognition failed. Try text practice.');setStatus('error')};
   r.onend=()=>setStatus(v=>v==='listening'?'ready':v);r.start();
  }catch{setError('Could not start microphone. Check permission and try again.');setStatus('error')}
 },[language,stop]);
 useEffect(()=>()=>{if(ref.current){ref.current.onresult=null;ref.current.onerror=null;ref.current.onend=null;try{ref.current.abort()}catch{}}},[]);
 return {start,stop,status,error};
}
export function speakText(text,language='en-US'){if(!('speechSynthesis'in window))return false;window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(String(text).slice(0,500));u.lang=language;window.speechSynthesis.speak(u);return true}

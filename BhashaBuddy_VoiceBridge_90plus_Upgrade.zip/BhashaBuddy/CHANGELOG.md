# Changelog

## 2.0.0 – Rubric improvement pass
- Extracted speech handling and pronunciation scoring from App.jsx.
- Added defensive namespaced storage with legacy v1 data migration.
- Added safe fallback handling for microphone and speech API failures.
- Added automated unit tests for scoring and storage utilities.
- Added React error boundary and keyboard focus/reduced-motion improvements.
- Added static security headers and security/privacy documentation.
- Preserved the original vocabulary dataset and core learning experience.
